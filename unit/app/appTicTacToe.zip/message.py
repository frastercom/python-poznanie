def winmessage(s):
	return "WIN"