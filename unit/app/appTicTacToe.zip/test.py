def winxy(s):
    if s[0] == s[1] and s[1] == s[2]:
        return True
    return False